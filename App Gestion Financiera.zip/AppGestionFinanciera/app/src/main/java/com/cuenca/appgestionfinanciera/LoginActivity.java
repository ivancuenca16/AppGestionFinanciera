package com.cuenca.appgestionfinanciera;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/**
 * Activity para manejar el login “manual” contra Realtime Database
 * sin utilizar Firebase Authentication.
 */
public class LoginActivity extends AppCompatActivity {

    private EditText etUsername, etPassword;
    private Button btnLogin;
    private TextView tvErrorLogin;
    private ProgressDialog progressDialog;

    // Referencia a la raíz de la base de datos
    private DatabaseReference usuariosRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // 1) Inicializar vistas
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvErrorLogin = findViewById(R.id.tvErrorLogin);

        // 2) Inicializar ProgressDialog (opcional, muestra “cargando…”)
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Iniciando sesión...");
        progressDialog.setCancelable(false);

        // 3) Obtener referencia a “users” en Realtime Database
        usuariosRef = FirebaseDatabase.getInstance()
                .getReference("users");

        // 4) Configurar evento click en el botón de login
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Ocultar mensaje de error previo
                tvErrorLogin.setVisibility(View.GONE);

                // Obtener valores ingresados
                final String username = etUsername.getText().toString().trim();
                final String password = etPassword.getText().toString().trim();

                // Validar que no estén vacíos
                if (TextUtils.isEmpty(username)) {
                    etUsername.setError("Ingresa tu usuario");
                    return;
                }
                if (TextUtils.isEmpty(password)) {
                    etPassword.setError("Ingresa tu contraseña");
                    return;
                }

                // Mostrar diálogo de progreso
                progressDialog.show();

                // Intentaremos leer el nodo de ese usuario en particular
                // (asumiendo que la clave de cada usuario en la BD es su “username”)
                usuariosRef.child(username)
                        .addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                progressDialog.dismiss();

                                if (snapshot.exists()) {
                                    // Si existe el nodo del usuario, extraemos el campo "password"
                                    String passwordEnBD = snapshot.child("password")
                                            .getValue(String.class);

                                    if (passwordEnBD != null && passwordEnBD.equals(password)) {
                                        // Contraseña coincide → login exitoso
                                        Toast.makeText(LoginActivity.this,
                                                "¡Bienvenido, " + username + "!",
                                                Toast.LENGTH_SHORT).show();

                                        // Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                        Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                                        startActivity(intent);
                                        finish();


                                    } else {
                                        // Contraseña no coincide
                                        tvErrorLogin.setText("Contraseña incorrecta.");
                                        tvErrorLogin.setVisibility(View.VISIBLE);
                                    }
                                } else {
                                    // No existe un usuario con ese username
                                    tvErrorLogin.setText("Usuario no encontrado.");
                                    tvErrorLogin.setVisibility(View.VISIBLE);
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                                progressDialog.dismiss();
                                // Error de lectura de BD
                                Toast.makeText(LoginActivity.this,
                                        "Error al leer la base de datos: "
                                                + error.getMessage(),
                                        Toast.LENGTH_LONG).show();
                            }
                        });
            }
        });
    }
}
