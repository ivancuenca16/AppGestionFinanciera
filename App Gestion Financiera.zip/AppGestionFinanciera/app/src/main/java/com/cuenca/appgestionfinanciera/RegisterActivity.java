package com.cuenca.appgestionfinanciera; // ajústalo a tu paquete real

import android.app.ProgressDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/**
 * Activity para registrar un nuevo usuario en Realtime Database.
 */
public class RegisterActivity extends AppCompatActivity {

    private EditText etNewUsername, etNewPassword, etNewNombre, etNewEmail;
    private Button btnRegister;
    private TextView tvErrorRegistro;
    private ProgressDialog progressDialog;

    // Referencia a la rama "users" en Realtime Database
    private DatabaseReference usuariosRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // 1) Inicializar vistas
        etNewUsername  = findViewById(R.id.etNewUsername);
        etNewPassword  = findViewById(R.id.etNewPassword);
        etNewNombre    = findViewById(R.id.etNewNombre);
        etNewEmail     = findViewById(R.id.etNewEmail);
        btnRegister    = findViewById(R.id.btnRegister);
        tvErrorRegistro= findViewById(R.id.tvErrorRegistro);

        // 2) Inicializar ProgressDialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Creando cuenta...");
        progressDialog.setCancelable(false);

        // 3) Obtener referencia a "users" en la BD
        usuariosRef = FirebaseDatabase.getInstance().getReference("users");

        // 4) Configurar click en "Registrar"
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvErrorRegistro.setVisibility(View.GONE);

                final String username = etNewUsername.getText().toString().trim();
                final String password = etNewPassword.getText().toString().trim();
                final String nombre   = etNewNombre.getText().toString().trim();
                final String email    = etNewEmail.getText().toString().trim();

                // Validar que no haya campos vacíos
                if (TextUtils.isEmpty(username)) {
                    etNewUsername.setError("Ingresa un usuario");
                    return;
                }
                if (TextUtils.isEmpty(password)) {
                    etNewPassword.setError("Ingresa una contraseña");
                    return;
                }
                if (TextUtils.isEmpty(nombre)) {
                    etNewNombre.setError("Ingresa tu nombre");
                    return;
                }
                if (TextUtils.isEmpty(email)) {
                    etNewEmail.setError("Ingresa tu email");
                    return;
                }

                // Mostrar diálogo de progreso
                progressDialog.show();

                // Primero verificamos que no exista ya ese username en la BD
                usuariosRef.child(username)
                        .addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if (snapshot.exists()) {
                                    // Ya hay un nodo con ese username → no se permite duplicar
                                    progressDialog.dismiss();
                                    tvErrorRegistro.setText("El usuario ya existe.");
                                    tvErrorRegistro.setVisibility(View.VISIBLE);
                                } else {
                                    // No existe: creamos un nuevo objeto Usuario
                                    Usuario nuevoUsuario = new Usuario(password, nombre, email);

                                    // Guardamos bajo "users/{username}"
                                    usuariosRef.child(username)
                                            .setValue(nuevoUsuario, new DatabaseReference.CompletionListener() {
                                                @Override
                                                public void onComplete(DatabaseError error, @NonNull DatabaseReference ref) {
                                                    progressDialog.dismiss();
                                                    if (error == null) {
                                                        // Registro exitoso
                                                        Toast.makeText(RegisterActivity.this,
                                                                "Cuenta creada correctamente",
                                                                Toast.LENGTH_SHORT).show();
                                                        // Opcional: terminar esta activity y volver a MainActivity
                                                        finish();
                                                    } else {
                                                        // Hubo algún error al escribir
                                                        tvErrorRegistro.setText("Error al registrar: " +
                                                                error.getMessage());
                                                        tvErrorRegistro.setVisibility(View.VISIBLE);
                                                    }
                                                }
                                            });
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                                progressDialog.dismiss();
                                tvErrorRegistro.setText("Error al acceder a la DB: " +
                                        error.getMessage());
                                tvErrorRegistro.setVisibility(View.VISIBLE);
                            }
                        });
            }
        });
    }

    /**
     * Clase POJO para representar un usuario en Realtime Database.
     * (Asegúrate de crear este archivo Usuario.java o anidarlo como clase estática)
     */
    public static class Usuario {
        public String password;
        public String nombre;
        public String email;

        // Constructor vacío requerido por Firebase
        public Usuario() { }

        public Usuario(String password, String nombre, String email) {
            this.password = password;
            this.nombre   = nombre;
            this.email    = email;
        }
    }
}
