package com.cuenca.appgestionfinanciera;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.google.android.material.bottomnavigation.BottomNavigationView;

/**
 * HomeActivity con BottomNavigationView que carga tres fragments:
 * - FragmentAgrega     (pantalla de “Agregar”)
 * - FragmentLista      (pantalla de “Listar”)
 * - FragmentPeriodicos (pantalla de “Periódicos”)
 *
 * Modificaciones:
 * 1) El título se cambia a "FinanApp" llamando a getSupportActionBar().setTitle(...)
 * 2) El fragment que se muestra al iniciar pasa a ser FragmentLista (en lugar de FragmentAgrega).
 */
public class HomeActivity extends AppCompatActivity {

    private BottomNavigationView bottomNav;
    private FragmentManager fragmentManager;

    private FragmentAgrega fragmentAgrega;
    private FragmentLista fragmentLista;
    private FragmentPeriodicos fragmentPeriodicos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Asignamos el título de la AppBar a "FinanApp"
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("FinanApp");
        }

        // 1) Inicializar el FragmentManager
        fragmentManager = getSupportFragmentManager();

        // 2) Instanciar los fragments
        fragmentAgrega     = new FragmentAgrega();
        fragmentLista      = new FragmentLista();
        fragmentPeriodicos = new FragmentPeriodicos();

        // 3) Obtener la referencia al BottomNavigationView
        bottomNav = findViewById(R.id.bottom_navigation);

        // 4) Al iniciar, mostramos por defecto el fragment “Listar”
        fragmentManager.beginTransaction()
                .replace(R.id.containerFragments, fragmentLista)
                .commit();

        // 5) Listener para cambios de pestañas usando if/else en lugar de switch/case
        bottomNav.setOnNavigationItemSelectedListener(item -> {
            Fragment seleccionado = null;
            int id = item.getItemId();

            if (id == R.id.nav_agregar) {
                seleccionado = fragmentAgrega;
            }
            else if (id == R.id.nav_listar) {
                seleccionado = fragmentLista;
            }
            else if (id == R.id.nav_periodicos) {
                seleccionado = fragmentPeriodicos;
            }

            if (seleccionado != null) {
                fragmentManager.beginTransaction()
                        .replace(R.id.containerFragments, seleccionado)
                        .commit();
                return true;
            }
            return false;
        });
    }
}
