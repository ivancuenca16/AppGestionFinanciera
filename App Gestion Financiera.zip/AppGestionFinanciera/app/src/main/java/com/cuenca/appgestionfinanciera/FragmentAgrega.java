package com.cuenca.appgestionfinanciera;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.UUID;

/**
 * FragmentAgrega: interfaz para introducir un ingreso o gasto
 */
public class FragmentAgrega extends Fragment {

    // UI
    private MaterialButtonToggleGroup toggleTipo;
    private MaterialButton btnIngreso, btnGasto;
    private TextInputLayout tilImporte, tilDescripcion;
    private TextInputEditText etImporte, etDescripcion;
    private Spinner spinnerCategoria;
    private MaterialButton btnSeleccionarFecha;
    private TextView tvFechaSeleccionada;
    private MaterialButton btnGuardarMovimiento;
    private TextView tvMensajeAgrega;

    // Fecha
    private Calendar calendar;
    private SimpleDateFormat sdf;

    // Firebase
    private DatabaseReference transRef;

    public FragmentAgrega() {
        // Constructor vacío (requerido)
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_agrega, container, false);

        // 1) Vincular vistas
        toggleTipo           = view.findViewById(R.id.toggleTipo);
        btnIngreso           = view.findViewById(R.id.btnIngreso);
        btnGasto             = view.findViewById(R.id.btnGasto);
        tilImporte           = view.findViewById(R.id.tilImporte);
        etImporte            = view.findViewById(R.id.etImporte);
        spinnerCategoria     = view.findViewById(R.id.spinnerCategoria);
        tilDescripcion       = view.findViewById(R.id.tilDescripcion);
        etDescripcion        = view.findViewById(R.id.etDescripcion);
        btnSeleccionarFecha  = view.findViewById(R.id.btnSeleccionarFecha);
        tvFechaSeleccionada  = view.findViewById(R.id.tvFechaSeleccionada);
        btnGuardarMovimiento = view.findViewById(R.id.btnGuardarMovimiento);
        tvMensajeAgrega      = view.findViewById(R.id.tvMensajeAgrega);

        // 2) Fecha por defecto = hoy
        calendar = Calendar.getInstance();
        sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        tvFechaSeleccionada.setText(sdf.format(calendar.getTime())); // muestra “2025-06-06” por ejemplo

        // 3) Llenar Spinner de categorías (usa el array definido en strings.xml)
        ArrayAdapter<CharSequence> adapterCategorias = ArrayAdapter.createFromResource(
                requireContext(),
                R.array.categorias_array,
                android.R.layout.simple_spinner_item
        );
        adapterCategorias.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategoria.setAdapter(adapterCategorias);

        // 4) Referencia a “transactions” en Firebase Realtime Database
        transRef = FirebaseDatabase.getInstance().getReference("transactions");

        // 5) Configurar DatePickerDialog al pulsar “Elegir fecha”
        btnSeleccionarFecha.setOnClickListener(v -> {
            int year  = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day   = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog dpd = new DatePickerDialog(
                    requireContext(),
                    (view1, year1, month1, dayOfMonth) -> {
                        calendar.set(Calendar.YEAR, year1);
                        calendar.set(Calendar.MONTH, month1);
                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        tvFechaSeleccionada.setText(sdf.format(calendar.getTime()));
                    },
                    year, month, day
            );
            dpd.show();
        });

        // 6) Botón “Guardar”
        btnGuardarMovimiento.setOnClickListener(v -> {
            tvMensajeAgrega.setVisibility(View.GONE);
            tilImporte.setError(null);

            // 6.1) Leer valores ingresados
            String importeStr = etImporte.getText().toString().trim();
            String descripcion = etDescripcion.getText().toString().trim();
            String categoria = spinnerCategoria.getSelectedItem().toString();
            String fecha = sdf.format(calendar.getTime());

            // Tipo: si btnIngreso está seleccionado → “ingreso”, sino “gasto”
            String tipo = (toggleTipo.getCheckedButtonId() == R.id.btnIngreso) ? "ingreso" : "gasto";

            // 6.2) Validar importe
            if (TextUtils.isEmpty(importeStr)) {
                tilImporte.setError("Ingresa un importe");
                return;
            }
            double importe;
            try {
                importe = Double.parseDouble(importeStr);
                if (importe <= 0) {
                    tilImporte.setError("Debe ser mayor que cero");
                    return;
                }
            } catch (NumberFormatException e) {
                tilImporte.setError("Formato inválido");
                return;
            }

            // 6.3) Generar ID único para la transacción
            String idTrans = UUID.randomUUID().toString();

            // 6.4) Crear objeto Transaction y guardar en Firebase
            Transaction nuevaTrans = new Transaction(
                    idTrans,
                    tipo,
                    categoria,
                    descripcion,
                    importe,
                    fecha,
                    false // no es periódico
            );

            transRef.child(idTrans).setValue(nuevaTrans)
                    .addOnSuccessListener(aVoid -> {
                        // Éxito: mostrar Toast y limpiar campos
                        Toast.makeText(requireContext(),
                                "Guardado correctamente",
                                Toast.LENGTH_SHORT).show();

                        // Limpiar campos
                        etImporte.setText("");
                        etDescripcion.setText("");
                        spinnerCategoria.setSelection(0);
                        toggleTipo.check(R.id.btnIngreso);
                        calendar = Calendar.getInstance();
                        tvFechaSeleccionada.setText(sdf.format(calendar.getTime()));
                    })
                    .addOnFailureListener(e -> {
                        tvMensajeAgrega.setText("Error al guardar: " + e.getMessage());
                        tvMensajeAgrega.setVisibility(View.VISIBLE);
                    });
        });

        return view;
    }

    // ---------- POJO para la transacción ----------
    public static class Transaction {
        public String id;
        public String tipo;         // "ingreso" o "gasto"
        public String categoria;
        public String descripcion;
        public double importe;
        public String fecha;        // "yyyy-MM-dd"
        public boolean periodico;   // false por defecto

        public Transaction() {
            // Constructor vacío para Firebase
        }

        public Transaction(String id, String tipo, String categoria,
                           String descripcion, double importe,
                           String fecha, boolean periodico) {
            this.id = id;
            this.tipo = tipo;
            this.categoria = categoria;
            this.descripcion = descripcion;
            this.importe = importe;
            this.fecha = fecha;
            this.periodico = periodico;
        }
    }
}
