package com.cuenca.appgestionfinanciera;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * FragmentLista: lee todas las transacciones de Firebase, las filtra
 * por búsqueda, tipo y categoría, y muestra el RecyclerView con TransactionAdapter.
 */
public class FragmentLista extends Fragment {

    private TextInputEditText etBuscar;
    private Spinner spinnerTipoFiltro, spinnerCategoriaFiltro;
    private RecyclerView rvTransacciones;
    private TextView tvSinResultados;

    private DatabaseReference transRef;
    private List<Transaction> allTransactions = new ArrayList<>();
    private TransactionAdapter adapter;

    public FragmentLista() { }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_lista, container, false);

        // 1) Vincular vistas
        etBuscar               = view.findViewById(R.id.etBuscar);
        spinnerTipoFiltro      = view.findViewById(R.id.spinnerTipoFiltro);
        spinnerCategoriaFiltro = view.findViewById(R.id.spinnerCategoriaFiltro);
        rvTransacciones        = view.findViewById(R.id.rvTransacciones);
        tvSinResultados        = view.findViewById(R.id.tvSinResultados);

        // 2) Configurar RecyclerView y adapter con lista vacía inicialmente
        rvTransacciones.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new TransactionAdapter(new ArrayList<>());
        rvTransacciones.setAdapter(adapter);

        // 3) Configurar spinners con sus arrays
        ArrayAdapter<CharSequence> adapterTipo = ArrayAdapter.createFromResource(
                requireContext(),
                R.array.filtro_tipo,
                android.R.layout.simple_spinner_item
        );
        adapterTipo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTipoFiltro.setAdapter(adapterTipo);

        ArrayAdapter<CharSequence> adapterCat = ArrayAdapter.createFromResource(
                requireContext(),
                R.array.categorias_array,
                android.R.layout.simple_spinner_item
        );
        adapterCat.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategoriaFiltro.setAdapter(adapterCat);

        // 4) Listener para búsqueda desde teclado (IME “Buscar”)
        etBuscar.setOnEditorActionListener((TextView textView, int actionId, KeyEvent keyEvent) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                applyFilters(); // volvemos a filtrar toda la lista
                return true;
            }
            return false;
        });

        // 5) Listeners de los spinners: al cambiar, reaplicar filtros
        spinnerTipoFiltro.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent,
                                       View v, int position, long id) {
                applyFilters();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });
        spinnerCategoriaFiltro.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent,
                                       View v, int position, long id) {
                applyFilters();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        // 6) Referencia a “transactions” en Firebase
        transRef = FirebaseDatabase.getInstance().getReference("transactions");

        // 7) Leer todos los datos en cuanto el fragment se crea
        loadAllTransactionsFromFirebase();

        return view;
    }

    /**
     * Lee todas las transacciones de Firebase y las almacena en allTransactions.
     * Luego aplica filtro inicial (sin restricciones).
     */
    private void loadAllTransactionsFromFirebase() {
        transRef.addValueEventListener(new com.google.firebase.database.ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                allTransactions.clear();
                for (DataSnapshot ds : snapshot.getChildren()) {
                    Transaction tx = ds.getValue(Transaction.class);
                    if (tx != null) {
                        allTransactions.add(tx);
                    }
                }
                applyFilters();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(requireContext(),
                        "Error al cargar datos: " + error.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    /**
     * Toma la lista completa (allTransactions), aplica filtros de búsqueda, tipo y categoría,
     * y actualiza el adapter con la lista filtrada.
     */
    private void applyFilters() {
        String textoBuscar = etBuscar.getText().toString().trim().toLowerCase();
        String tipoSeleccionado = spinnerTipoFiltro.getSelectedItem().toString();
        String catSeleccionada   = spinnerCategoriaFiltro.getSelectedItem().toString();

        List<Transaction> filtered = new ArrayList<>();
        for (Transaction tx : allTransactions) {
            // 1) Filtrar por texto: si se proporcionó texto, que coincida con categoría o descripción
            boolean matchesText = textoBuscar.isEmpty()
                    || tx.categoria.toLowerCase().contains(textoBuscar)
                    || (tx.descripcion != null && tx.descripcion.toLowerCase().contains(textoBuscar));

            // 2) Filtrar por tipo: si “Todos” está seleccionado, aceptamos ambos; si “Ingreso” o “Gasto”, comparamos
            boolean matchesTipo = tipoSeleccionado.equals("Todos")
                    || tx.tipo.equalsIgnoreCase(tipoSeleccionado.toLowerCase());

            // 3) Filtrar por categoría: si “Todas” está seleccionado, aceptamos todas; si otra, la coincida
            boolean matchesCategoria = catSeleccionada.equals("Todas")
                    || tx.categoria.equalsIgnoreCase(catSeleccionada);

            if (matchesText && matchesTipo && matchesCategoria) {
                filtered.add(tx);
            }
        }

        // 4) Actualizar adapter y mostrar/ocultar “No hay movimientos”
        adapter.updateList(filtered);
        if (filtered.isEmpty()) {
            tvSinResultados.setVisibility(View.VISIBLE);
        } else {
            tvSinResultados.setVisibility(View.GONE);
        }
    }
}
